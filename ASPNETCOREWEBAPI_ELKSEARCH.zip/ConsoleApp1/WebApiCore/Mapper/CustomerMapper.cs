﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCore.Models;

namespace WebApiCore.Mapper
{
    public static class CustomerMapper
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="customerDto"></param>
        /// <returns></returns>
        public static Customer CustomerDtoToCustomer(Dto.CustomerDto customerDto)
        {
            Customer customer = new Customer();
            customer.Id = customerDto.Id;
            customer.Name = customerDto.Name;
            customer.Address = customerDto.Address;
            customer.Phone = customerDto.Phone;
            customer.Email = customerDto.Email;

            return customer;
        }
    }
}
