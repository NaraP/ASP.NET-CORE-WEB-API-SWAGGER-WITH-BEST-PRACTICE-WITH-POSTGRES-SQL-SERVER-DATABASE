﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiCore.Helper
{
    public sealed class ResponseMessage : ResponseMessageBase
    {
        public ResponseMessage()
        {
        }
        public ResponseMessage(int statusCode, string statusDescription, string errorMessage, object returnObj) : base(statusCode, statusDescription, errorMessage, returnObj)
        {
        }
    }
}
