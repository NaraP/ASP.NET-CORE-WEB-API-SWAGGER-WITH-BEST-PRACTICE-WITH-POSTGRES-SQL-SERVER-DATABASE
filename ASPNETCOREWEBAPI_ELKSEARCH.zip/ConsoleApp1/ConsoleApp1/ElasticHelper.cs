﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Serilog;
using Serilog.Events;
using Serilog.Exceptions;
using Serilog.Sinks.Elasticsearch;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace ConsoleApp1
{
	//var pool = new SingleNodeConnectionPool(new Uri("http://52.172.25.120:32894"

	public static class ElasticHelper
    {
		public static void CreateHost(string[] args)
		{
			try
			{
				var host = new HostBuilder().Build();
				host.Start();
			}

			catch (System.Exception ex)
			{
				Log.Fatal($"Failed to start {Assembly.GetExecutingAssembly().GetName().Name}", ex);
				throw;
			}
		}

		public static void ConfigureLogging()
		{
			var environment = Environment.GetEnvironmentVariable("ElasticConfigurationUrl");

			var configuration = new ConfigurationBuilder()
				.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
				.AddJsonFile(
					$"appsettings.{Environment.GetEnvironmentVariable("ElasticConfigurationUrl")}.json",
					optional: true).AddEnvironmentVariables()
				.Build();

			if (!String.IsNullOrEmpty(environment))
			{
				Log.Logger = new LoggerConfiguration()
				   .Enrich.FromLogContext()
				   .Enrich.WithExceptionDetails()
				   .Enrich.WithMachineName()
				   .WriteTo.Elasticsearch(new ElasticsearchSinkOptions(new Uri(environment))
				   {
					   AutoRegisterTemplate = true,
					   MinimumLogEventLevel = LogEventLevel.Verbose
				   })
				.CreateLogger();
			}
		}

		public static ElasticsearchSinkOptions ConfigureElasticSink(IConfigurationRoot configuration, string environment)
		{
			return new ElasticsearchSinkOptions(new Uri(environment))
			{
				AutoRegisterTemplate = true,
				IndexFormat = $"{Assembly.GetExecutingAssembly().GetName().Name.ToLower().Replace(".", "-")}-{environment?.ToLower().Replace(".", "-")}-{DateTime.UtcNow:yyyy-MM}"
			};
		}
	}
}
