﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public class Car
    {
        public int? CarID { get; set; }
        public string Maker { get; set; }
        public string Color { get; set; }
        public Double? Milage { get; set; }
        public Double? Price { get; set; }
        public DateTime? CreatedDate { get; set; }
    }
}
